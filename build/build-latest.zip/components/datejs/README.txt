For a quick tutorial on getting started with Datejs, please visit the following links...

http://www.datejs.com/2007/11/27/getting-started-with-datejs/

http://code.google.com/p/datejs/

Hope this helps!